x=msgbox("this malware is no joke",4+48,"WARNING!!")
x=msgbox("this will destroy system files!!",4+16,"WARNING!!")
x=msgbox("I am not responsible for any damages...",4+16,"WARNING!!")